
#! python3
# venv: brg-csd
# r: compas_rv

import pathlib

import compas
from compas.datastructures import Mesh
from compas.geometry import Vector
from compas.scene import Scene

# =============================================================================
# Load data
# =============================================================================


IFILE = pathlib.Path(__file__).parent / "009_mesh.json"
dual = compas.json_load(IFILE)

# =============================================================================
# Bottom mesh for scaffolding.
# =============================================================================

vertices, faces = dual.to_vertices_and_faces()

bottom_points = []
for vertex in dual.vertices():
    point = dual.vertex_point(vertex)
    thickness = dual.vertex_attribute(vertex, "thickness") * 0.5
    normal = Vector(*dual.vertex_normal(vertex))
    bottom_point  = point -  thickness * normal
    bottom_points.append(bottom_point)

bottom_mesh = Mesh.from_vertices_and_faces(bottom_points, faces)


# =============================================================================
# Visualisation
# =============================================================================

scene = Scene()
scene.add(bottom_mesh, color=(255,0,0))
scene.draw()

